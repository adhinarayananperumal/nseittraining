package com.hdfc.corebankingnseit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CorebankingnseitApplicationTests {

	@Test
	void contextLoads() {
	}

}
