package com.hdfc.corebankingnseit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CorebankingnseitApplication {

	public static void main(String[] args) {
		SpringApplication.run(CorebankingnseitApplication.class, args);
	}

}
