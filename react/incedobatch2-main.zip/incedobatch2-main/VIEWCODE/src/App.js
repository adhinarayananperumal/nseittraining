import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>   Online Shopping App</h1>
      </header>
      <h3> Welcome to AA Online  Portal</h3>
    </div>
  );
}

export default  App;
