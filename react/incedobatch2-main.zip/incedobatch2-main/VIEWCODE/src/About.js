export default function About() {
    return (
      <div>
        <h2>...We are 20 years company based out of india</h2>
      </div>
    );
  }
  