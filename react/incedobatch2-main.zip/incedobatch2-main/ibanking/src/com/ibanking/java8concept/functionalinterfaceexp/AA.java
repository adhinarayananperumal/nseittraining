package com.ibanking.java8concept.functionalinterfaceexp;

public class AA {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
