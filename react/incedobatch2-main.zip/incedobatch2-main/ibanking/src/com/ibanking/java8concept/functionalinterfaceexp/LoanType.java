package com.ibanking.java8concept.functionalinterfaceexp;

public interface LoanType {
	
	LoanPojo createLoan(LoanPojo loanPojo);

}
