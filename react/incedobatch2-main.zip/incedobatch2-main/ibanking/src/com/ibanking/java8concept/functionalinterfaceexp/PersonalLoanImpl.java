package com.ibanking.java8concept.functionalinterfaceexp;

public class PersonalLoanImpl implements Loan {

	@Override
	public String createLoan() {

		// store in database
		// generate loan Id
		// send email

		return "pl34567";
	}

}
